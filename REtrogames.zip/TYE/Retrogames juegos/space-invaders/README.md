# Space Invaders

A Pen created on CodePen.io. Original URL: [https://codepen.io/adelciotto/pen/WNzRYy](https://codepen.io/adelciotto/pen/WNzRYy).

A simple space invaders game that I wrote during my early university years.  I apologise for the quality of the code and missing gameplay features. Press left and right arrow keys to move and the X key to fire.